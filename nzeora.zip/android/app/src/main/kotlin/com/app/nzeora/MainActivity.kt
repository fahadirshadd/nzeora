package com.app.nzeora

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
